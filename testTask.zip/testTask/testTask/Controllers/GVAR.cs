﻿using System.Collections.Concurrent;
using System.Data;
using Newtonsoft.Json;

namespace testTask.Controllers
{
    
    public class GVAR
    {
        [JsonProperty("DicOfDic")]
        public ConcurrentDictionary<string, ConcurrentDictionary<string, string>> DicOfDic = new ConcurrentDictionary<string, ConcurrentDictionary<string, string>>();
        [JsonProperty("DicOfDT")]
        public ConcurrentDictionary<string,DataTable>DicOfDT=new ConcurrentDictionary<string,DataTable>();


    }
}
