﻿using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System;

//cd C:\Users\hala\source\repos\testTask


namespace testTask.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DBConnectionController : ControllerBase
    {
        // Your connection string (usually you should store it securely, e.g., in appsettings.json)
        private string connString = "Host=localhost;Port=5432;Database=hala__FMS;Username=postgres;Password=123456789@";
        //private string connString = "Host=localhost;Port=5432;Database=taskdb;Username=postgres;Password=wrongpassword";

        // Endpoint to test the connection
        [HttpGet("test-connection")]
        public IActionResult TestConnection()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    // Execute some queries or operations
                    using (var cmd = new NpgsqlCommand("SELECT * FROM public.\"Vehicles\"", conn))
                    {
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                // Read columns using the correct types
                                long vehicleID = reader.GetInt64(0); // First column is bigint
                                long vehicleNumber = reader.IsDBNull(1) ? 0 : reader.GetInt64(1); // Second column is bigint (check for NULL)
                                string vehicleType = reader.IsDBNull(2) ? "N/A" : reader.GetString(2); // Third column is varchar

                                // Print the data
                                Console.WriteLine($"VehicleID: {vehicleID}, VehicleNumber: {vehicleNumber}, VehicleType: {vehicleType}");
                            }
                        }
                    }

                    return Ok("Connection successful!");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Connection failed: {ex.Message}");
            }
        }
    }
}
