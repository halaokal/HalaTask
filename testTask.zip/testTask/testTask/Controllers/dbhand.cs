﻿using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System;

//cd C:\Users\hala\source\repos\testTask


namespace testTask.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DBhandController : ControllerBase
    {
        // Your connection string (usually you should store it securely, e.g., in appsettings.json)
        private string connString = "Host=localhost;Port=5432;Database=hala__FMS;Username=postgres;Password=123456789@";
        //private string connString = "Host=localhost;Port=5432;Database=taskdb;Username=postgres;Password=wrongpassword";

        // Endpoint to test the connection
        [HttpGet("test-connection")]
        public IActionResult TestConnection()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = "INSERT INTO public.\"Vehicles\" (\"VehicleNumber\", \"VehicleType\") VALUES (@VehicleNumber, @VehicleType)";

                    // Execute some queries or operations
                    using (var cmd = new NpgsqlCommand(query, conn))

                    {
                            // Add parameters with values
                            cmd.Parameters.AddWithValue("VehicleNumber", 23); // Example vehicle number
                            cmd.Parameters.AddWithValue("VehicleType", "bus");  // Example vehicle type

                            // Execute the query
                            int rowsAffected = cmd.ExecuteNonQuery();

                            // Optionally, check how many rows were affected
                            Console.WriteLine($"{rowsAffected} row(s) inserted.");
                    }

                    return Ok("Connection successful!");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Connection failed: {ex.Message}");
            }
        }
    }
}
