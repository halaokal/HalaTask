﻿using System;
using System.Data;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Npgsql;
using testTask.Controllers.classes;

namespace testTask.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RouteHistoryController : ControllerBase
    {
        private readonly string connString = "Host=localhost;Port=5432;Database=hala__FMS;Username=postgres;Password=123456789@";

        [HttpGet("get-route-history")]
        public IActionResult GetRouteHistory(long vehicleId, long startEpoch, long endEpoch)
        {
            try
            {
                GVAR gvar = new GVAR();
                DataTable routeHistoryTable = new DataTable();

                // Open connection and execute query
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = SqlQueries.Queries["GetRouteHistoryByVehicleAndTimeRange"];

                    // Create command and parameters
                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@VehicleID", vehicleId);
                        cmd.Parameters.AddWithValue("@StartEpoch", startEpoch);
                        cmd.Parameters.AddWithValue("@EndEpoch", endEpoch);

                        // Execute reader
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (!reader.HasRows)
                            {
                                return NotFound("No records found for the given VehicleID and time range.");
                            }

                            // Load results into DataTable
                            routeHistoryTable.Load(reader);
                        }
                    }
                }

                // Add the route history data to the response
                gvar.DicOfDT["RouteHistory"] = routeHistoryTable;
                return Ok(gvar);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }




        [HttpPost("add-route-history")]
        public IActionResult AddRouteHistory([FromBody] GVAR gvar)
        {
            if (gvar == null)
            {
                return BadRequest("Request body is null.");
            }

            Console.WriteLine("Received Request Body: " + JsonConvert.SerializeObject(gvar));

            if (gvar.DicOfDic == null || !gvar.DicOfDic.ContainsKey("Tags"))
            {
                return BadRequest("Invalid request. 'Tags' dictionary is missing.");
            }

            try
            {
                var tags = gvar.DicOfDic["Tags"];

                if (!tags.ContainsKey("VehicleID") || !tags.ContainsKey("VehicleDirection") || !tags.ContainsKey("Status") ||
                    !tags.ContainsKey("VehicleSpeed") || !tags.ContainsKey("Epoch") || !tags.ContainsKey("Address") ||
                    !tags.ContainsKey("Latitude") || !tags.ContainsKey("Longitude"))
                {
                    return BadRequest("Missing required route history data.");
                }

                long vehicleID = long.Parse(tags["VehicleID"]);
                int vehicleDirection = int.Parse(tags["VehicleDirection"]);
                char status = char.Parse(tags["Status"]);
                string vehicleSpeed = tags["VehicleSpeed"];
                long epoch = long.Parse(tags["Epoch"]);
                string address = tags["Address"];
                float latitude = float.Parse(tags["Latitude"]);
                float longitude = float.Parse(tags["Longitude"]);

                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = SqlQueries.Queries["InsertRouteHistory"];
                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("VehicleID", vehicleID);
                        cmd.Parameters.AddWithValue("VehicleDirection", vehicleDirection);
                        cmd.Parameters.AddWithValue("Status", status);
                        cmd.Parameters.AddWithValue("VehicleSpeed", vehicleSpeed);
                        cmd.Parameters.AddWithValue("Epoch", epoch);
                        cmd.Parameters.AddWithValue("Address", address);
                        cmd.Parameters.AddWithValue("Latitude", latitude);
                        cmd.Parameters.AddWithValue("Longitude", longitude);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            return Ok("Route history added successfully.");
                        }
                        else
                        {
                            return StatusCode(500, "Failed to add route history.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpPut("update-route-history/{routeHistoryID}")]
        public IActionResult UpdateRouteHistory(long routeHistoryID, [FromBody] GVAR gvar)
        {
            if (gvar == null)
            {
                return BadRequest("Request body is null.");
            }

            Console.WriteLine("Received Request Body: " + JsonConvert.SerializeObject(gvar));

            if (gvar.DicOfDic == null || !gvar.DicOfDic.ContainsKey("Tags"))
            {
                return BadRequest("Invalid request. 'Tags' dictionary is missing.");
            }

            try
            {
                var tags = gvar.DicOfDic["Tags"];

                if (!tags.ContainsKey("VehicleDirection") || !tags.ContainsKey("Status") ||
                    !tags.ContainsKey("VehicleSpeed") || !tags.ContainsKey("Address") ||
                    !tags.ContainsKey("Latitude") || !tags.ContainsKey("Longitude"))
                {
                    return BadRequest("Missing required route history data.");
                }

                int vehicleDirection = int.Parse(tags["VehicleDirection"]);
                char status = char.Parse(tags["Status"]);
                string vehicleSpeed = tags["VehicleSpeed"];
                string address = tags["Address"];
                float latitude = float.Parse(tags["Latitude"]);
                float longitude = float.Parse(tags["Longitude"]);

                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    string checkQuery = SqlQueries.Queries["CheckRouteHistoryExistence"];
                    using (var cmd = new NpgsqlCommand(checkQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("RouteHistoryID", routeHistoryID);
                        int recordExists = Convert.ToInt32(cmd.ExecuteScalar());

                        if (recordExists == 0)
                        {
                            return NotFound($"Route history with ID {routeHistoryID} not found.");
                        }
                    }

                    string updateQuery = SqlQueries.Queries["UpdateRouteHistory"];
                    using (var cmd = new NpgsqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("RouteHistoryID", routeHistoryID);
                        cmd.Parameters.AddWithValue("VehicleDirection", vehicleDirection);
                        cmd.Parameters.AddWithValue("Status", status);
                        cmd.Parameters.AddWithValue("VehicleSpeed", vehicleSpeed);
                        cmd.Parameters.AddWithValue("Address", address);
                        cmd.Parameters.AddWithValue("Latitude", latitude);
                        cmd.Parameters.AddWithValue("Longitude", longitude);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            return Ok($"Route history {routeHistoryID} updated successfully.");
                        }
                        else
                        {
                            return StatusCode(500, "Failed to update the route history.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("delete-route-history/{routeHistoryID}")]
        public IActionResult DeleteRouteHistory(long routeHistoryID)
        {
            if (routeHistoryID <= 0)
            {
                return BadRequest("Invalid RouteHistoryID.");
            }

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    string checkQuery = SqlQueries.Queries["CheckRouteHistoryExistence"];
                    using (var cmd = new NpgsqlCommand(checkQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("RouteHistoryID", routeHistoryID);
                        int recordExists = Convert.ToInt32(cmd.ExecuteScalar());

                        if (recordExists == 0)
                        {
                            return NotFound($"Route history with ID {routeHistoryID} not found.");
                        }
                    }

                    string deleteQuery = SqlQueries.Queries["DeleteRouteHistory"];
                    using (var cmd = new NpgsqlCommand(deleteQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("RouteHistoryID", routeHistoryID);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            return Ok($"Route history with ID {routeHistoryID} deleted successfully.");
                        }
                        else
                        {
                            return StatusCode(500, "Failed to delete the route history.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
