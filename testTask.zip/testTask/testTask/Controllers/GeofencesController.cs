﻿using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System;
using System.Data;
using testTask.Controllers.classes;

namespace testTask.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class GeofencesController : ControllerBase
    {
        private readonly string connString = "Host=localhost;Port=5432;Database=hala__FMS;Username=postgres;Password=123456789@";

        [HttpGet("get-geofences")]
        public IActionResult GetGeofences()
        {
            return ExecuteQuery("GetGeofences", "Geofences");
        }

        [HttpGet("get-polygon-geofences")]
        public IActionResult GetPolygonGeofences()
        {
            return ExecuteQuery("GetPolygonGeofences", "PolygonGeofences");
        }

        [HttpGet("get-rectangle-geofences")]
        public IActionResult GetRectangleGeofences()
        {
            return ExecuteQuery("GetRectangleGeofences", "RectangleGeofences");
        }

        [HttpGet("get-circle-geofences")]
        public IActionResult GetCircleGeofences()
        {
            return ExecuteQuery("GetCircleGeofences", "CircleGeofences");
        }

        private IActionResult ExecuteQuery(string queryKey, string tableName)
        {
            try
            {
                GVAR gvar = new GVAR();
                DataTable dataTable = new DataTable();

                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = SqlQueries.Queries[queryKey];  // Get the query from SqlQueries

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (!reader.HasRows)
                            {
                                return NotFound($"No data found for {tableName}.");
                            }
                            dataTable.Load(reader);
                        }
                    }
                }

                gvar.DicOfDT[tableName] = dataTable;  // Store the result in the GVAR object
                return Ok(gvar);  // Return the data
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
