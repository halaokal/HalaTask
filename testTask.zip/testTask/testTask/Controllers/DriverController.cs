﻿using System.Data;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Npgsql;
using testTask.Controllers.classes;

namespace testTask.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DriverController : ControllerBase
    {
        private readonly string connString = "Host=localhost;Port=5432;Database=hala__FMS;Username=postgres;Password=123456789@";

        [HttpGet("get-drivers")]
        public IActionResult GetDrivers()
        {
            try
            {
                GVAR gvar = new GVAR();
                DataTable driversTable = new DataTable();
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = SqlQueries.Queries["GetDrivers"];
                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (!reader.HasRows)
                            {
                                return NotFound("No records found in the Driver table.");
                            }

                            driversTable.Load(reader);
                        }
                    }
                }
                gvar.DicOfDT["Drivers"] = driversTable;
                functions fun = new functions();
                return Ok(gvar);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("add-driver")]
        public IActionResult AddNewDriver([FromBody] GVAR gvar)
        {
            if (gvar == null)
            {
                return BadRequest("Request body is null.");
            }
            Console.WriteLine("Received Request Body: " + JsonConvert.SerializeObject(gvar));

            if (gvar.DicOfDic == null || !gvar.DicOfDic.ContainsKey("Tags"))
            {
                return BadRequest("Invalid request. 'Tags' dictionary is missing.");
            }

            try
            {
                var tags = gvar.DicOfDic["Tags"];

                // Extract driver data
                if (!tags.ContainsKey("DriverName") || !tags.ContainsKey("PhoneNumber"))
                {
                    return BadRequest("Missing required driver data (DriverName or PhoneNumber).");
                }

                string driverName = tags["DriverName"];
                long phoneNumber;

                if (!long.TryParse(tags["PhoneNumber"], out phoneNumber))
                {
                    return BadRequest("Invalid PhoneNumber format.");
                }

                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = SqlQueries.Queries["InsertDriver"];
                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("DriverName", driverName);
                        cmd.Parameters.AddWithValue("PhoneNumber", phoneNumber);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            return Ok($"Driver {driverName} added successfully.");
                        }
                        else
                        {
                            return StatusCode(500, "Failed to add the driver.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("update-driver/{driverID}")]
        public IActionResult UpdateDriver(long driverID, [FromBody] GVAR gvar)
        {
            if (gvar == null)
            {
                return BadRequest("Request body is null.");
            }

            Console.WriteLine("Received Request Body: " + JsonConvert.SerializeObject(gvar));

            if (gvar.DicOfDic == null || !gvar.DicOfDic.ContainsKey("Tags"))
            {
                return BadRequest("Invalid request. 'Tags' dictionary is missing.");
            }

            try
            {
                var tags = gvar.DicOfDic["Tags"];

                if (!tags.ContainsKey("DriverName") || !tags.ContainsKey("PhoneNumber"))
                {
                    return BadRequest("Missing required driver data (DriverName or PhoneNumber).");
                }

                string driverName = tags["DriverName"];
                long phoneNumber;

                if (!long.TryParse(tags["PhoneNumber"], out phoneNumber))
                {
                    return BadRequest("Invalid PhoneNumber format.");
                }

                // Check if the driver exists in the database
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    string checkQuery = SqlQueries.Queries["CheckDriverExistence"];
                    using (var cmd = new NpgsqlCommand(checkQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("DriverID", driverID);
                        int driverExists = Convert.ToInt32(cmd.ExecuteScalar());

                        if (driverExists == 0)
                        {
                            return NotFound($"Driver with ID {driverID} not found.");
                        }
                    }

                    // Update the driver
                    string updateQuery = SqlQueries.Queries["UpdateDriver"];
                    using (var cmd = new NpgsqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("DriverID", driverID);
                        cmd.Parameters.AddWithValue("DriverName", driverName);
                        cmd.Parameters.AddWithValue("PhoneNumber", phoneNumber);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            return Ok($"Driver {driverID} updated successfully.");
                        }
                        else
                        {
                            return StatusCode(500, "Failed to update the driver.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("delete-driver/{driverID}")]
        public IActionResult DeleteDriver(long driverID)
        {
            if (driverID <= 0)
            {
                return BadRequest("Invalid DriverID.");
            }

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    // Check if the driver exists
                    string checkQuery = SqlQueries.Queries["CheckDriverExistence"];
                    using (var cmd = new NpgsqlCommand(checkQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("DriverID", driverID);
                        int driverExists = Convert.ToInt32(cmd.ExecuteScalar());

                        if (driverExists == 0)
                        {
                            return NotFound($"Driver with ID {driverID} not found.");
                        }
                    }

                    // Delete the driver
                    string deleteQuery = SqlQueries.Queries["DeleteDriver"];
                    using (var cmd = new NpgsqlCommand(deleteQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("DriverID", driverID);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            return Ok($"Driver with ID {driverID} deleted successfully.");
                        }
                        else
                        {
                            return StatusCode(500, "Failed to delete the driver.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
