﻿namespace testTask.Controllers.classes
{
    using System;
    using Npgsql;

    public class Vehicle
    {
        public long VehicleID { get; set; }
        public long? VehicleNumber { get; set; }
        public string VehicleType { get; set; }

        public Vehicle() { }

        public Vehicle(long vehicleID, long? vehicleNumber, string vehicleType)
        {
            VehicleID = vehicleID;
            VehicleNumber = vehicleNumber;
            VehicleType = vehicleType;
        }
    }

}
