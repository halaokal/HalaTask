﻿using System.Data;

namespace testTask.Controllers.classes
{
    public class functions
    {
        public object ConvertDataTableToStructuredJson(DataTable dt)
        {
            return new
            {
                Columns = dt.Columns.Cast<DataColumn>().Select(col => col.ColumnName).ToList(),
                Rows = dt.AsEnumerable()
                         .Select(row => row.ItemArray.ToList())
                         .ToList()
            };
        }

    }
}
