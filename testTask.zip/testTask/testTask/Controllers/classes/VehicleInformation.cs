﻿namespace testTask.Controllers.classes
{
    using System;
    using Npgsql;

    public class VehicleInformation
    {
        public long ID { get; set; }
        public long? VehicleID { get; set; }
        public long? DriverID { get; set; }
        public string VehicleMake { get; set; }
        public string VehicleModel { get; set; }
        public long? PurchaseDate { get; set; }

        public VehicleInformation() { }

        public VehicleInformation(long id, long? vehicleID, long? driverID, string vehicleMake, string vehicleModel, long? purchaseDate)
        {
            ID = id;
            VehicleID = vehicleID;
            DriverID = driverID;
            VehicleMake = vehicleMake;
            VehicleModel = vehicleModel;
            PurchaseDate = purchaseDate;
        }
    }
}
