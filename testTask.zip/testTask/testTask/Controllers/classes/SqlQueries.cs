﻿namespace testTask.Controllers.classes
{
    public static class SqlQueries
    {
        public static readonly Dictionary<string, string> Queries = new Dictionary<string, string>
    {
        // Queries for Vehicles
        
        { "GetVehiclesWithRouteHistory", "SELECT " +
                "v.\"VehicleID\", " +
                "v.\"VehicleNumber\", " +
                "v.\"VehicleType\", " +
                "rh.\"VehicleDirection\" AS \"LastDirection\", " +
                "rh.\"Status\" AS \"LastStatus\", " +
                "rh.\"Address\" AS \"LastAddress\", " +
                "rh.\"Latitude\" AS \"LastLatitude\", " +
                "rh.\"Longitude\" AS \"LastLongitude\" " +
                "FROM public.\"Vehicles\" v " +
                "LEFT JOIN public.\"RouteHistory\" rh " +
                "ON v.\"VehicleID\" = rh.\"VehicleID\" " +
                "WHERE rh.\"RouteHistoryID\" = ( " +
                    "SELECT MAX(\"RouteHistoryID\") " +
                    "FROM public.\"RouteHistory\" " +
                    "WHERE \"VehicleID\" = v.\"VehicleID\"" +
                ")"
            },

        { "GetVehicleByIdWithRouteHistory", "SELECT " +
                    "v.\"VehicleID\", " +
                    "v.\"VehicleNumber\", " +
                    "v.\"VehicleType\", " +
                    "d.\"DriverName\", " +
                    "d.\"PhoneNumber\", " +
                    "rh.\"Latitude\" || ', ' || rh.\"Longitude\" AS \"LastPosition\", " +
                    "vi.\"VehicleMake\", " +
                    "vi.\"VehicleModel\", " +
                    "to_timestamp(rh.\"Epoch\") AS \"LastGPSTime\", " +
                    "rh.\"VehicleSpeed\" AS \"LastGPSSpeed\", " +
                    "rh.\"Address\" AS \"LastAddress\" " +
                    "FROM public.\"Vehicles\" v " +
                    "JOIN public.\"VehiclesInformations\" vi ON v.\"VehicleID\" = vi.\"VehicleID\" " +
                    "JOIN public.\"Driver\" d ON vi.\"DriverID\" = d.\"DriverID\" " +
                    "LEFT JOIN public.\"RouteHistory\" rh ON v.\"VehicleID\" = rh.\"VehicleID\" " +
                    "WHERE v.\"VehicleID\" = @VehicleID " +
                    "ORDER BY rh.\"RouteHistoryID\" DESC " +
                    "LIMIT 1"
            },



        { "GetVehicles", "SELECT * FROM public.\"Vehicles\"" },
        { "CheckVehicleExistence", "SELECT COUNT(*) FROM public.\"Vehicles\" WHERE \"VehicleNumber\" = @VehicleNumber" },
        { "InsertVehicle", "INSERT INTO public.\"Vehicles\" (\"VehicleNumber\", \"VehicleType\") VALUES (@VehicleNumber, @VehicleType)" },
        { "UpdateVehicle", "UPDATE public.\"Vehicles\" SET \"VehicleType\" = @VehicleType WHERE \"VehicleNumber\" = @VehicleNumber" },
        { "DeleteVehicle", "DELETE FROM public.\"Vehicles\" WHERE \"VehicleNumber\" = @VehicleNumber" },

         // Queries for Driver
        { "GetDrivers", "SELECT * FROM public.\"Driver\"" },
        { "CheckDriverExistence", "SELECT COUNT(*) FROM public.\"Driver\" WHERE \"DriverID\" = @DriverID" },
        { "InsertDriver", "INSERT INTO public.\"Driver\" (\"DriverName\", \"PhoneNumber\") VALUES (@DriverName, @PhoneNumber)" },
        { "UpdateDriver", "UPDATE public.\"Driver\" SET \"DriverName\" = @DriverName, \"PhoneNumber\" = @PhoneNumber WHERE \"DriverID\" = @DriverID" },
        { "DeleteDriver", "DELETE FROM public.\"Driver\" WHERE \"DriverID\" = @DriverID" },
        
        // Queries for VehicleInformation
        { "GetVehicleInformation", "SELECT * FROM public.\"VehiclesInformations\"" },
        { "InsertVehicleInformation", "INSERT INTO public.\"VehiclesInformations\" (\"VehicleID\", \"DriverID\", \"VehicleMake\", \"VehicleModel\", \"PurchaseDate\") VALUES (@VehicleID, @DriverID, @VehicleMake, @VehicleModel, @PurchaseDate)" },
        { "CheckVehicleInformationExistence", "SELECT COUNT(*) FROM public.\"VehiclesInformations\" WHERE \"ID\" = @ID" },
        { "UpdateVehicleInformation", "UPDATE public.\"VehiclesInformations\" SET \"VehicleMake\" = @VehicleMake, \"VehicleModel\" = @VehicleModel WHERE \"ID\" = @ID" },
        { "DeleteVehicleInformation", "DELETE FROM public.\"VehiclesInformations\" WHERE \"ID\" = @ID" },
         
        // Queries for RouteHistory
        { "GetRouteHistory", "SELECT * FROM public.\"RouteHistory\"" },
        { "InsertRouteHistory", "INSERT INTO public.\"RouteHistory\" (\"VehicleID\", \"VehicleDirection\", \"Status\", \"VehicleSpeed\", \"Epoch\", \"Address\", \"Latitude\", \"Longitude\") VALUES (@VehicleID, @VehicleDirection, @Status, @VehicleSpeed, @Epoch, @Address, @Latitude, @Longitude)" },
        { "CheckRouteHistoryExistence", "SELECT COUNT(*) FROM public.\"RouteHistory\" WHERE \"RouteHistoryID\" = @RouteHistoryID" },
        { "UpdateRouteHistory", "UPDATE public.\"RouteHistory\" SET \"VehicleDirection\" = @VehicleDirection, \"Status\" = @Status, \"VehicleSpeed\" = @VehicleSpeed, \"Address\" = @Address, \"Latitude\" = @Latitude, \"Longitude\" = @Longitude WHERE \"RouteHistoryID\" = @RouteHistoryID" },
        { "DeleteRouteHistory", "DELETE FROM public.\"RouteHistory\" WHERE \"RouteHistoryID\" = @RouteHistoryID" },
               { "GetRouteHistoryByVehicleAndTimeRange",
                 "SELECT " +
                 "v.\"VehicleID\", " +
                 "v.\"VehicleNumber\", " +
                 "rh.\"Address\", " +
                 "rh.\"Status\", " +
                 "rh.\"Latitude\", " +
                 "rh.\"Longitude\", " +
                 "rh.\"VehicleDirection\", " +
                 "rh.\"VehicleSpeed\" AS \"GPSSpeed\", " +
                 "to_timestamp(rh.\"Epoch\") AS \"GPSTime\" " +
                 "FROM public.\"Vehicles\" v " +
                 "JOIN public.\"RouteHistory\" rh ON v.\"VehicleID\" = rh.\"VehicleID\" " +
                 "WHERE v.\"VehicleID\" = @VehicleID " +  // Replace @VehicleID with the vehicle ID parameter
                 "AND rh.\"Epoch\" BETWEEN @StartEpoch AND @EndEpoch " +  // Replace with the epoch range
                 "ORDER BY rh.\"Epoch\""},





               // Query for retrieving geofence information
            { "GetGeofences", "SELECT " +
                              "\"GeofenceID\", " +
                              "\"GeofenceType\", " +
                              "\"AddedDate\", " +
                              "\"StrockColor\", " +
                              "\"StrockOpacity\", " +
                              "\"StrockWeight\", " +
                              "\"FillColor\", " +
                              "\"FillOpacity\" " +
                              "FROM public.\"Geofences\"" },
            { "GetPolygonGeofences", "SELECT * FROM public.\"PolygonGeofence\" pg " +
                          "JOIN public.\"Geofences\" g ON pg.\"GeofenceID\" = g.\"GeofenceID\"" },

            { "GetRectangleGeofences", "SELECT * FROM public.\"RectangleGeofence\" rg " +
                           "JOIN public.\"Geofences\" g ON rg.\"GeofenceID\" = g.\"GeofenceID\"" },

            { "GetCircleGeofences", "SELECT * FROM public.\"CircleGeofence\" cg " +
                        "JOIN public.\"Geofences\" g ON cg.\"GeofenceID\" = g.\"GeofenceID\"" }












    };
    }

}
