﻿using System.Data;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Npgsql;
using testTask.Controllers.classes;

namespace testTask.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class VehiclesController : ControllerBase
    {
        private readonly string connString = "Host=localhost;Port=5432;Database=hala__FMS;Username=postgres;Password=123456789@";
        [HttpGet("get-vehicles")]
        public IActionResult GetVehicles()
        {
            try 
            {
                GVAR gvar = new GVAR();
                DataTable vehiclesTable = new DataTable();
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();                  
                    string query = SqlQueries.Queries["GetVehiclesWithRouteHistory"];
                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (!reader.HasRows)
                            {
                                return NotFound("No records found in the Vehicles table.");
                            }

                            vehiclesTable.Load(reader);

                            foreach (DataRow row in vehiclesTable.Rows) // for debug (need to remove)
                            {
                                Console.WriteLine($"Row fetched: {row["VehicleID"]}");
                            }
                        }
                    }
                }
                gvar.DicOfDT["Vehicles"] = vehiclesTable;            
                functions fun=new functions(); 
                return Ok(gvar);
              
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }

        }
        
            [HttpGet("get-vehicle/{vehicleId}")]
            public IActionResult GetVehicleById(long vehicleId)
            {
                try
                {
                    GVAR gvar = new GVAR();
                    DataTable vehicleInfoTable = new DataTable();

                    // Open connection to the database
                    using (var conn = new NpgsqlConnection(connString))
                    {
                        conn.Open();

                        // Query to fetch vehicle details along with the latest route history
                        string query = SqlQueries.Queries["GetVehicleByIdWithRouteHistory"];

                        using (var cmd = new NpgsqlCommand(query, conn))
                        {
                            // Add parameter to prevent SQL injection
                            cmd.Parameters.AddWithValue("@VehicleID", vehicleId);

                            using (var reader = cmd.ExecuteReader())
                            {
                                if (!reader.HasRows)
                                {
                                    return NotFound("No records found for the given Vehicle ID.");
                                }

                                // Load the data into the DataTable
                                vehicleInfoTable.Load(reader);
                            }
                        }
                    }

                    // Store the result in the GVAR object
                    gvar.DicOfDT["VehicleInfo"] = vehicleInfoTable;

                    // Return the data as a JSON response
                    return Ok(gvar);
                }
                catch (Exception ex)
                {
                    // Handle any exceptions and return a server error
                    return StatusCode(500, $"Internal server error: {ex.Message}");
                }
            }






            [HttpPost("add-vehicle")]
        public IActionResult AddNewVehicle([FromBody] GVAR gvar)
        {
            if (gvar == null)
            {
                return BadRequest("Request body is null.");
            }
            Console.WriteLine("Received Request Body: " + JsonConvert.SerializeObject(gvar));

            if (gvar.DicOfDic == null || !gvar.DicOfDic.ContainsKey("Tags"))
            {
                return BadRequest("Invalid request. 'Tags' dictionary is missing.");
            }

            try
            {
                var tags = gvar.DicOfDic["Tags"];

                // Extract vehicle data
                if (!tags.ContainsKey("VehicleNumber") || !tags.ContainsKey("VehicleType"))
                {
                    return BadRequest("Missing required vehicle data (VehicleNumber or VehicleType).");
                }

                long vehicleNumber;


                if (!long.TryParse(tags["VehicleNumber"], out vehicleNumber))
                {
                    return BadRequest("Invalid VehicleNumber format.");
                }

                string vehicleType = tags["VehicleType"];

                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    //string query = "INSERT INTO public.\"Vehicles\" (\"VehicleNumber\", \"VehicleType\") VALUES (@VehicleNumber, @VehicleType)";
                    string query = SqlQueries.Queries["InsertVehicle"];
                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("VehicleNumber", vehicleNumber);
                        cmd.Parameters.AddWithValue("VehicleType", vehicleType);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            Console.WriteLine($"Vehicle {vehicleNumber} added successfully.");
                            return Ok($"Vehicle {vehicleNumber} added successfully.");
                        }
                        else
                        {
                            return StatusCode(500, "Failed to add the vehicle.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }




        [HttpPut("update-vehicle/{vehicleNumber}")]
        public IActionResult UpdateVehicle(long vehicleNumber, [FromBody] GVAR gvar)
        {
            if (gvar == null)
            {
                return BadRequest("Request body is null.");
            }

            Console.WriteLine("Received Request Body: " + JsonConvert.SerializeObject(gvar));

            // Check if DicOfDic and Tags exist
            if (gvar.DicOfDic == null || !gvar.DicOfDic.ContainsKey("Tags"))
            {
                return BadRequest("Invalid request. 'Tags' dictionary is missing.");
            }

            try
            {
                var tags = gvar.DicOfDic["Tags"];

                // Extract vehicle data
                if (!tags.ContainsKey("VehicleType"))
                {
                    return BadRequest("Missing required vehicle data (VehicleType).");
                }

                string vehicleType = tags["VehicleType"];

                // Check if the vehicle exists in the database
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    // Check if the vehicle exists
                    string checkQuery = SqlQueries.Queries["CheckVehicleExistence"];
                    using (var cmd = new NpgsqlCommand(checkQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("VehicleNumber", vehicleNumber);
                        int vehicleExists = Convert.ToInt32(cmd.ExecuteScalar());

                        if (vehicleExists == 0)
                        {
                            return NotFound($"Vehicle with number {vehicleNumber} not found.");
                        }
                    }

                    // Update the vehicle
                    string updateQuery = "UPDATE public.\"Vehicles\" SET \"VehicleType\" = @VehicleType WHERE \"VehicleNumber\" = @VehicleNumber";
                    using (var cmd = new NpgsqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("VehicleNumber", vehicleNumber);
                        cmd.Parameters.AddWithValue("VehicleType", vehicleType);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            return Ok($"Vehicle {vehicleNumber} updated successfully.");
                        }
                        else
                        {
                            return StatusCode(500, "Failed to update the vehicle.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }



        


        [HttpDelete("delete-vehicle/{vehicleNumber}")]
        public IActionResult DeleteVehicle(long vehicleNumber)
        {
            if (vehicleNumber <= 0)
            {
                return BadRequest("Invalid VehicleNumber.");
            }

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    // Check if the vehicle exists
                    string checkQuery = SqlQueries.Queries["CheckVehicleExistence"];
                    using (var cmd = new NpgsqlCommand(checkQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("VehicleNumber", vehicleNumber);
                        int vehicleExists = Convert.ToInt32(cmd.ExecuteScalar());

                        if (vehicleExists == 0)
                        {
                            return NotFound($"Vehicle with number {vehicleNumber} not found.");
                        }
                    }

                    // Delete the vehicle
                    string deleteQuery = "DELETE FROM public.\"Vehicles\" WHERE \"VehicleNumber\" = @VehicleNumber";
                    using (var cmd = new NpgsqlCommand(deleteQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("VehicleNumber", vehicleNumber);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            return Ok($"Vehicle with number {vehicleNumber} deleted successfully.");
                        }
                        else
                        {
                            return StatusCode(500, "Failed to delete the vehicle.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }











    }
}
