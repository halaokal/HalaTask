﻿using System.Data;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Npgsql;
using testTask.Controllers.classes;

namespace testTask.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class VehicleInformationController : ControllerBase
    {
        private readonly string connString = "Host=localhost;Port=5432;Database=hala__FMS;Username=postgres;Password=123456789@";

        // GET: /vehicleinformation/get-vehicle-information
        [HttpGet("get-vehicle-information")]
        public IActionResult GetVehicleInformation()
        {
            try
            {
                GVAR gvar = new GVAR();
                DataTable vehicleInfoTable = new DataTable();
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = SqlQueries.Queries["GetVehicleInformation"];
                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (!reader.HasRows)
                            {
                                return NotFound("No records found in the VehiclesInformation table.");
                            }

                            vehicleInfoTable.Load(reader);
                        }
                    }
                }
                gvar.DicOfDT["VehiclesInformation"] = vehicleInfoTable;
                return Ok(gvar);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // POST: /vehicleinformation/add-vehicle-information
        [HttpPost("add-vehicle-information")]
        public IActionResult AddVehicleInformation([FromBody] GVAR gvar)
        {
            if (gvar == null || gvar.DicOfDic == null || !gvar.DicOfDic.ContainsKey("Tags"))
            {
                return BadRequest("Invalid request. 'Tags' dictionary is missing.");
            }

            try
            {
                var tags = gvar.DicOfDic["Tags"];
                if (!tags.ContainsKey("VehicleID") || !tags.ContainsKey("DriverID") ||
                    !tags.ContainsKey("VehicleMake") || !tags.ContainsKey("VehicleModel") || !tags.ContainsKey("PurchaseDate"))
                {
                    return BadRequest("Missing required vehicle information data.");
                }

                long vehicleID = Convert.ToInt64(tags["VehicleID"]);
                long driverID = Convert.ToInt64(tags["DriverID"]);
                string vehicleMake = tags["VehicleMake"];
                string vehicleModel = tags["VehicleModel"];
                long purchaseDate = Convert.ToInt64(tags["PurchaseDate"]);

                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = SqlQueries.Queries["InsertVehicleInformation"];
                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("VehicleID", vehicleID);
                        cmd.Parameters.AddWithValue("DriverID", driverID);
                        cmd.Parameters.AddWithValue("VehicleMake", vehicleMake);
                        cmd.Parameters.AddWithValue("VehicleModel", vehicleModel);
                        cmd.Parameters.AddWithValue("PurchaseDate", purchaseDate);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0
                            ? Ok($"Vehicle Information for VehicleID {vehicleID} added successfully.")
                            : StatusCode(500, "Failed to add vehicle information.");
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // PUT: /vehicleinformation/update-vehicle-information/{id}
        [HttpPut("update-vehicle-information/{id}")]
        public IActionResult UpdateVehicleInformation(long id, [FromBody] GVAR gvar)
        {
            if (gvar == null || gvar.DicOfDic == null || !gvar.DicOfDic.ContainsKey("Tags"))
            {
                return BadRequest("Invalid request. 'Tags' dictionary is missing.");
            }

            try
            {
                var tags = gvar.DicOfDic["Tags"];
                if (!tags.ContainsKey("VehicleMake") || !tags.ContainsKey("VehicleModel"))
                {
                    return BadRequest("Missing required vehicle information data.");
                }

                string vehicleMake = tags["VehicleMake"];
                string vehicleModel = tags["VehicleModel"];

                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    // Check if record exists
                    string checkQuery = SqlQueries.Queries["CheckVehicleInformationExistence"];
                    using (var cmd = new NpgsqlCommand(checkQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("ID", id);
                        int recordExists = Convert.ToInt32(cmd.ExecuteScalar());

                        if (recordExists == 0)
                        {
                            return NotFound($"Vehicle information with ID {id} not found.");
                        }
                    }

                    // Update the vehicle information
                    string updateQuery = SqlQueries.Queries["UpdateVehicleInformation"];
                    using (var cmd = new NpgsqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("ID", id);
                        cmd.Parameters.AddWithValue("VehicleMake", vehicleMake);
                        cmd.Parameters.AddWithValue("VehicleModel", vehicleModel);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0
                            ? Ok($"Vehicle information with ID {id} updated successfully.")
                            : StatusCode(500, "Failed to update vehicle information.");
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // DELETE: /vehicleinformation/delete-vehicle-information/{id}
        [HttpDelete("delete-vehicle-information/{id}")]
        public IActionResult DeleteVehicleInformation(long id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid ID.");
            }

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    // Check if record exists
                    string checkQuery = SqlQueries.Queries["CheckVehicleInformationExistence"];
                    using (var cmd = new NpgsqlCommand(checkQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("ID", id);
                        int recordExists = Convert.ToInt32(cmd.ExecuteScalar());

                        if (recordExists == 0)
                        {
                            return NotFound($"Vehicle information with ID {id} not found.");
                        }
                    }

                    // Delete the vehicle information
                    string deleteQuery = SqlQueries.Queries["DeleteVehicleInformation"];
                    using (var cmd = new NpgsqlCommand(deleteQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("ID", id);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0
                            ? Ok($"Vehicle information with ID {id} deleted successfully.")
                            : StatusCode(500, "Failed to delete vehicle information.");
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
